package com.gurjit.springbootwebflux_assign2_gurjitsingh.repository;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Book;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface BookRepository extends ReactiveMongoRepository<Book, String> {

    // Find all books by a given publisher ID
    Flux<Book> findByPublisherId(String publisherId);

    // Find books whose title contains a substring (case-insensitive)
    Flux<Book> findByTitleContainingIgnoreCase(String titlePart);
}
