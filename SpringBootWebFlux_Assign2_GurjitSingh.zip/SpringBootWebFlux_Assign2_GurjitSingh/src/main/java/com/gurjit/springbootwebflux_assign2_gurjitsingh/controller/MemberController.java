package com.gurjit.springbootwebflux_assign2_gurjitsingh.controller;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Member;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/members")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;

    @GetMapping
    public Flux<Member> getAll() {
        return memberService.getAll();
    }

    @GetMapping("/{id}")
    public Mono<Member> getById(@PathVariable String id) {
        return memberService.getById(id);
    }

    @PostMapping
    public Mono<Member> create(@RequestBody Member member) {
        return memberService.create(member);
    }

    @PutMapping("/{id}")
    public Mono<Member> update(@PathVariable String id, @RequestBody Member member) {
        return memberService.update(id, member);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> delete(@PathVariable String id) {
        return memberService.delete(id);
    }
}
