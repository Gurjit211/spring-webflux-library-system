package com.gurjit.springbootwebflux_assign2_gurjitsingh.repository;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Member;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepository extends ReactiveMongoRepository<Member, String> {
    // EXTRA queries are fine **as long as the field names exist**.
    // Example:
    // Flux<Member> findByMembType(String membType);
}
