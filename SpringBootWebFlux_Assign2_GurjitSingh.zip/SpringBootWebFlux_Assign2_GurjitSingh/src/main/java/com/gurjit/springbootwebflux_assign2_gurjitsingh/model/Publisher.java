package com.gurjit.springbootwebflux_assign2_gurjitsingh.model;
import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "publishers")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Publisher {
    @Id
    private String id;
    private String name;
    private String address;
}

/*
 Required	Covered by
All-fields constructor	@AllArgsConstructor
No-args constructor	@NoArgsConstructor
Getters & setters	@Data (includes both getters/setters, toString, equals, etc.)
MongoDB ID handling	@Id
MongoDB Collection	@Document(collection = "...")

So yes — the 3 model classes do meet the assignment's instructions.
They use clean, simple annotations instead of writing 50+ lines of repetitive code.
 */