package com.gurjit.springbootwebflux_assign2_gurjitsingh.service;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Book;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepo;

    /** Return all books */
    public Flux<Book> getAll() {
        return bookRepo.findAll();
    }

    /** Find a single book by its id */
    public Mono<Book> getById(String id) {
        return bookRepo.findById(id);
    }

    /** Insert a new book */
    public Mono<Book> create(Book book) {
        return bookRepo.save(book);
    }

    /** Update an existing book */
    public Mono<Book> update(String id, Book updated) {
        return bookRepo.findById(id)
                .flatMap(existing -> {
                    existing.setTitle(updated.getTitle());
                    existing.setAuthor(updated.getAuthor());
                    existing.setPrice(updated.getPrice());
                    existing.setPublisherId(updated.getPublisherId());
                    return bookRepo.save(existing);
                });
    }

    /** Delete a book by its id */
    public Mono<Void> delete(String id) {
        return bookRepo.deleteById(id);
    }
}
