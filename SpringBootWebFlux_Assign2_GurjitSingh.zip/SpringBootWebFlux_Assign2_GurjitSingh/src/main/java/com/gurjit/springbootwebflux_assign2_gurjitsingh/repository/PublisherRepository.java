package com.gurjit.springbootwebflux_assign2_gurjitsingh.repository;


import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Publisher;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Mono;

public interface PublisherRepository extends ReactiveMongoRepository<Publisher, String> {

    // Example: look up a publisher by exact name
    Mono<Publisher> findByName(String name);
}
