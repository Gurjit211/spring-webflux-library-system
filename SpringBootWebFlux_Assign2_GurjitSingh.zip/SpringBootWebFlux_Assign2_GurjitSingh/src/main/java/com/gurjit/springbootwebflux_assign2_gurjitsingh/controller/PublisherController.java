package com.gurjit.springbootwebflux_assign2_gurjitsingh.controller;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Publisher;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.service.PublisherService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/publishers")
@RequiredArgsConstructor
public class PublisherController {

    private final PublisherService publisherService;

    @GetMapping
    public Flux<Publisher> getAll() {
        return publisherService.getAll();
    }

    @GetMapping("/{id}")
    public Mono<Publisher> getById(@PathVariable String id) {
        return publisherService.getById(id);
    }

    @PostMapping
    public Mono<Publisher> create(@RequestBody Publisher publisher) {
        return publisherService.create(publisher);
    }

    @PutMapping("/{id}")
    public Mono<Publisher> update(@PathVariable String id,
                                  @RequestBody Publisher updated) {
        return publisherService.update(id, updated);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> delete(@PathVariable String id) {
        return publisherService.delete(id);
    }
}
