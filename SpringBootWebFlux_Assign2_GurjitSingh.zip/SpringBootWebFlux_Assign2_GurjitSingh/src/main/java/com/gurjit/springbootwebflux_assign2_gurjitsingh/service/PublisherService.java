package com.gurjit.springbootwebflux_assign2_gurjitsingh.service;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Publisher;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.repository.PublisherRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class PublisherService {

    private final PublisherRepository publisherRepo;

    public Flux<Publisher> getAll() {
        return publisherRepo.findAll();
    }

    public Mono<Publisher> getById(String id) {
        return publisherRepo.findById(id);
    }

    public Mono<Publisher> create(Publisher publisher) {
        return publisherRepo.save(publisher);
    }

    public Mono<Publisher> update(String id, Publisher updated) {
        return publisherRepo.findById(id)
                .flatMap(existing -> {
                    existing.setName(updated.getName());
                    existing.setAddress(updated.getAddress());
                    return publisherRepo.save(existing);
                });
    }

    public Mono<Void> delete(String id) {
        return publisherRepo.deleteById(id);
    }
}
