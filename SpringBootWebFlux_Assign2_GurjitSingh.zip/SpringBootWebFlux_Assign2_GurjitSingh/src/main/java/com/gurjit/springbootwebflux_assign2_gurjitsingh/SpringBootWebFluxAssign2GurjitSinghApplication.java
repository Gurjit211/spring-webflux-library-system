package com.gurjit.springbootwebflux_assign2_gurjitsingh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebFluxAssign2GurjitSinghApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootWebFluxAssign2GurjitSinghApplication.class, args);
    }

}
