package com.gurjit.springbootwebflux_assign2_gurjitsingh.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "books")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Book {
    @Id
    private String id;
    private String title;
    private String author;
    private double price;
    private boolean available;
    private String publisherId;
}
/*
 Required	Covered by
All-fields constructor	@AllArgsConstructor
No-args constructor	@NoArgsConstructor
Getters & setters	@Data (includes both getters/setters, toString, equals, etc.)
MongoDB ID handling	@Id
MongoDB Collection	@Document(collection = "...")

So yes — the 3 model classes do meet the assignment's instructions.
They use clean, simple annotations instead of writing 50+ lines of repetitive code.
 */