package com.gurjit.springbootwebflux_assign2_gurjitsingh.service;

import com.gurjit.springbootwebflux_assign2_gurjitsingh.model.Member;
import com.gurjit.springbootwebflux_assign2_gurjitsingh.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepo;

    public Flux<Member> getAll() {
        return memberRepo.findAll();
    }

    public Mono<Member> getById(String id) {
        return memberRepo.findById(id);
    }

    public Mono<Member> create(Member member) {
        return memberRepo.save(member);
    }

    public Mono<Member> update(String id, Member member) {
        return memberRepo.findById(id)
                .flatMap(existing -> {
                    existing.setName(member.getName());
                    existing.setAddress(member.getAddress());
                    existing.setMembType(member.getMembType());
                    existing.setMembDate(member.getMembDate());
                    existing.setExpiryDate(member.getExpiryDate());
                    return memberRepo.save(existing);
                });
    }

    public Mono<Void> delete(String id) {
        return memberRepo.deleteById(id);
    }
}
