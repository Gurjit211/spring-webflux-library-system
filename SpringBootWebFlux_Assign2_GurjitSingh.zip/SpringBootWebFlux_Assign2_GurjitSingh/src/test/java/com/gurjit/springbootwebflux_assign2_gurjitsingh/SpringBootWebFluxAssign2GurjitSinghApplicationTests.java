package com.gurjit.springbootwebflux_assign2_gurjitsingh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebFluxAssign2GurjitSinghApplicationTests {

    @Test
    void contextLoads() {
    }

}
